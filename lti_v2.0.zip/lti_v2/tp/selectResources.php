<?php
/*
$seperator = str_replace(".php","",$_SERVER['PHP_SELF']);
$uriParams = $_SERVER['REQUEST_URI']; 
$uriParamsArr = explode($seperator, $uriParams);
$paramSet = ltrim($uriParamsArr[1], "/");
$uriParamsArrValues = explode("/",$paramSet);

$ltriId = $uriParamsArrValues[0];
$guid = $uriParamsArrValues[1];
*/

require("../library/tpdatabase.php");
require_once ('../tp/Tool_Provider_Class.php');

// LOG FILE initialization
$logFilePath = '/var/www/html/lti_v2/logs/tool_log.txt';

// Object initialization for the tpDatabase class.
$tpDBObj = new tpdatabase();

//Capture the ltri_id & guid passed in URL from the tool_provider_class / toolRegistration action.
$ltriId = $_GET['ltri_id'];
$guid = $_GET['guid'];

$proceedFlag = FALSE;
$selCondition = " ltri_id = ".$ltriId." AND ltri_status = 'I' AND ltri_tc_guid = '".$guid."'";

$selectResponce = $tpDBObj->select('lti_tool_registration_info',array('ltri_status'),$selCondition);
if(isset($selectResponce) && $selectResponce['resultCount'] > 0){
    // don't do anything
    $proceedFlag = TRUE;
} else {
    echo "Invalid input parameters passing in the URL";die;
}

if(isset($_POST['submit']) && $_POST['submit'] == 'Save' && $proceedFlag){
	$postParams = $_POST;
	$resourceAccessLevel = $postParams['access_level']; // Value associated with label "Select the Access Level"
	$ltri_id = $postParams['ltri_id']; 
	
        // Below query checks whether provided $ltri_id & $guid are valid with respect to current registration process.
	if($proceedFlag){
	
            // Start generating the shared_secret
            $num = rand(10,20);
            $randomString = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, $num);
            // End generating the shared_secret
            
            // Update the shared_secret value into the table "lti_tool_registration_info"
            $updateArray['ltri_shared_secret'] = $randomString;
            $updateArray['ltri_resource_access_level'] = $resourceAccessLevel;
            $condition = " ltri_id = ".$ltri_id;
            $resp = $tpDBObj->updateData('lti_tool_registration_info', $updateArray, $condition);

            if($resp)
            {
                $proceed = TRUE;
                // user selected "Select the Access Level" value. pre-defined values 'd'/'s'/'m'
                // if selected 's' or 'm', then insert selected resource data into "lti_link_level_access" table.
                if($resourceAccessLevel != 'd'){
                    $proceed = FALSE;

                    //delete any pre-existing records
                    $delCondition = " ltri_id = ".$ltri_id;
                    $deleteStatus = $tpDBObj->deleteData('lti_link_level_access',$delCondition);

                    $resources = $postParams['resources'];
                    // start insertion of data into "lti_link_level_access" table
                    $insertArray['ltri_id'] = $ltri_id;
                    $insertArray['lti_link_level_access_dts'] = date('Y-m-d H:i:s');
                    if($resourceAccessLevel == 's'){
                        $insertArray['lti_resource_info_uniq_id'] = $resources[0];
                        $insertRole = $tpDBObj->insertDataInToTP($table = 'lti_link_level_access', $insertArray);
                        $insertCount = $courseCount = 1;
                    }  else {
                        $courseCount = count($resources);
                        $insertCount = 0;
                        foreach($resources as $ck=>$cv) {
                            $insertArray['lti_resource_info_uniq_id'] = $cv;
                            $insertRole = $tpDBObj->insertDataInToTP($table = 'lti_link_level_access', $insertArray);
                            if($insertRole){
                                $insertCount = $insertCount+1;
                            }
                        }
                    }
                }

                // Upon insertion/updation of data is success, will redirect the control to the "postToolProxyRegistrationToConsumer"
                // with the function input argument $ltri_id.
                if(($insertCount == $courseCount) || $proceed){

                    $tpObj = new Tool_Provider_Class();
                    $responseInformation = $tpObj->postToolProxyRegistrationToConsumer($ltri_id);

                    $msg = $responseInformation['message'];
                    if($responseInformation['status'] == 'success'){
                            if(isset($responseInformation['returnURL']) && strlen($responseInformation['returnURL']) > 10 ) {
                                    $returnURL = $responseInformation['returnURL'];
                                    $queryString    = parse_url($returnURL, PHP_URL_QUERY);
                                    if($queryString){
                                            $userprofileURL = trim($returnURL)."&amp;".$msg;
                                    } else {
                                            $userprofileURL = trim($returnURL)."?".$msg;
                                    }
                                    header("Location: $userprofileURL");
                            } else {
                                echo $msg; die;
                            }
                    } else {
                            $returnURL = $responseInformation['returnURL'];
                            if(isset($returnURL) && strlen($returnURL) > 4 ) {
                                    $queryString    = parse_url($returnURL, PHP_URL_QUERY);
                                    if($queryString){
                                            $userprofileURL = trim($returnURL)."&amp;".$msg;
                                    } else {
                                            $userprofileURL = trim($returnURL)."?".$msg;
                                    }
                                    header("Location: $userprofileURL");
                            } else {
                                    echo $msg; die;
                            }
                    }
                } else {
                    echo "error occured during insertionof the resources information."; die;
                }
            }
	} else {
            $invalidparamsMsg = "Provided ltri_id = < $ltri_id > & guid = < $guid > are invalid from the selectResource page \n";
            error_log($invalidparamsMsg, 3, $logFilePath);
            unset($invalidparamsMsg);
            echo "This request is already processed."; die;
	}
	
	
	
}

// Below query fetches the resources/courses information from the "lti_resource_info" table which are active(lti_resource_info_status = 1)
$condition = "lti_resource_info_status = 1";
$resourceInfo = $tpDBObj->select('lti_resource_info',array(),$condition);
$data = $resourceInfo['result'];

?>
<form action="<?php //echo $_SERVER['PHP_SELF']; ?>" method="post">
	<input type="hidden" value="<?php echo $ltriId; ?>" name="ltri_id" />
	<label> <b>Select the Access Level</b></label>
	<select name='access_level'>
		<option value="d">All resources</option>
		<option value="s">Specific resources</option>
		<option value="m">Multiple resources</option>
	</select>
	<br/>
	<br/>
	<label><b> Select the Resources</b></label>
	<br/>
		<?php  foreach($data as $rk=>$rv) { ?>
			<input type="checkbox" value="<?php echo $rv['lti_resource_info_uniq_id'];?>" name="resources[]"> 
			<?php echo $rv['lti_resource_info_uniq_id'];?><br/>
		<?php } ?>
	
	<br/>
	<br/>
	<input type="submit" value="Save" name="submit"/>
	</form>
