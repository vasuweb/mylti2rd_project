<?php
/***  ## Database Configuration ## **/
// FOR data base tc_lti
DEFINE('TC_LOCALHOST','localhost');
DEFINE('TC_USERNAME','root');
DEFINE('TC_PASSWORD','Impelsys1');
DEFINE('TC_DATABASE','tc_lti');

// FOR data base tp_lti
DEFINE('TP_LOCALHOST','localhost');
DEFINE('TP_USERNAME','root');
DEFINE('TP_PASSWORD','Impelsys1');
DEFINE('TP_DATABASE','tp_lti');

//CONSTANTS
DEFINE('ACTIVE',1);
DEFINE('INACTIVE',2);
DEFINE('LTI_ACTIVE',1);
DEFINE('LTI_INACTIVE',2);
DEFINE('LTI_VERSION','lti-2p0');

// Constants for database table names. 
DEFINE('LTI_ACCESS_ROLES','lti_access_roles');
DEFINE('LTI_CAPABILITIES','lti_capability'); // STORES DEFAULT TOOL PROVIDER capabilities for validation purpose.
DEFINE('LTI_LINK_LEVEL_ACCESS','lti_link_level_access');
DEFINE('LTI_RESOURCE_ACCESS','lti_resource_access');
DEFINE('LTI_RESOURCE_INFO','lti_resource_info');
DEFINE('LTI_TOOLCONSUMER_CAPABILITIES','lti_tc_capability');  // STORES all Tool Consumer provided capabilities.
DEFINE('LTI_TC_LAUNCH_DETAILS','lti_tc_launch_detail');
DEFINE('LTI_TOOLCONSUMER_SERVICES','lti_tc_service');
DEFINE('LTI_TOOL_REGISTRATION_INFO','lti_tool_registration_info');
DEFINE('LTI_TP_CONTENT','lti_tp_content'); // Replaced with Query during registration
DEFINE('LTI_USER_ROLE','lti_user_roles');

// CONSTANTS FOR TABLE COLUMNS
DEFINE('LTI_RESOURCE_INFO_REQ_ROLE','lti_resource_info_req_role'); // Whether this resource is configured for specific roles or not. Table : LTI_RESOURCE_INFO
DEFINE('LTI_RESOURCE_INFO_UNIQ_ID','lti_resource_info_uniq_id'); // It is the Resource UNIQ_ID which will be shared to TC for launching the course using this UNIQ ID.
DEFINE('LTI_RESOURCE_INFO_ID', 'lti_resource_info_id'); // Primary Key for LTI_RESOURCE_INFO table.
DEFINE('LTI_RESOURCE_INFO_URI_PARAM_ONE','lti_resource_info_uri_param_one'); // This is the reference field name for launching resource in my application, not mandatory.
DEFINE('LTI_RESOURCE_INFO_STATUS','lti_resource_info_status'); // Status of the resource is active or not (1/2) . Table - LTI_RESOURCE_INFO
DEFINE('TP_USER_ROLE_ID','tp_user_role_id'); // Is the role ID (PK) of the PROVIDER USer types table.
DEFINE('LTI_USER_ROLE_ID','lti_user_role_id'); // LTI_USER_ROLE table primary key.

//LOG file path
DEFINE('LOG_FILE_PATH','/var/www/html/lti_v2/logs/tool_log.txt');
DEFINE('SQL_LOG_FILE_PATH','/var/www/html/lti_v2/logs/sql_log.txt');

// REDIRECTION URL's
DEFINE('SELECT_CAPABILITIES_URL', 'http://mylocal/lti_v2/tp/selectResources.php'); // URL to which the TC will be redirected during registration process for selecting the Resources & Access Level fields.

// TEMP constants, can be deleted later-on
// yes or 'no' => If set to 'yes', then will cross validate the resources with respect to roles from the table : LTI_ACCESS_ROLES.
DEFINE('TP_ROLES','no');




?>
