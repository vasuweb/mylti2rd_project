
<?php
		ob_start();
                // Debugging 
		//error_reporting(E_ALL);
                //echo "<pre>"; print_r($_POST); die;
                
                //Including the tool_proxy_class.php file to use the toolRegistration() for process the registration request
                require_once ('../tp/Tool_Provider_Class.php');
                require_once ('../library/config.php');
                
                //LOG FILE PATH
                $logFilePath = SQL_LOG_FILE_PATH;
                
                /**
                 * To set the returnURL value, we check whether user provided "launch_presentation_return_url" value or not, 
                 * if not provided then, will take the URL from which he requested the toolRegistration.
                 */
		if(isset($_POST['launch_presentation_return_url'])) 
		{ $returnURLPath = $_POST['launch_presentation_return_url']; } else { $returnURL = $_SERVER['HTTP_REFERER']; }
		
		// Will check whether $returnURL having any query string param are not to append "?" or "&" key to the end of the URL.
		if (parse_url($returnURLPath, PHP_URL_QUERY))
		{ $returnURL = $returnURLPath."&"; } else {	$returnURL = $returnURLPath."?"; }
		
                // Unset any previously set POST param values to $postParams.
		unset($postParams);
                
		// Check whether HTTP request method is POST or not.
		if(strtolower($_SERVER['REQUEST_METHOD']) == 'post')
		{
			
			$postParams = $_POST;
			$messageType = trim($postParams['lti_message_type']);
			
			if(empty($messageType)){
				$errMsg = urlencode("Lti message type not defined");
				header('Location: ' . $returnURL."status=failure&message=".$errMsg); 
			}
			
			if(count($postParams) > 0){
                            
                            $messageType = strtolower($messageType);
                            
                            $tpObj = new Tool_Provider_Class();

                            // Check whether "lti_message_type" key is with the value "toolproxyregistrationrequest" or not.
                            if($messageType == 'toolproxyregistrationrequest'){
                                // redirect the control to the tool_provider_class for processing the request
                                $resp = $tpObj->toolRegisteration($postParams);
                                
                                if(isset($resp) && count($resp) > 0 ){
                                   $message = $resp['message'];
                                   $returnURLstring = $resp['finalreturnURL'];
                                   if($resp['status'] == 'success'){
                                       $succMsg = "Tool proxy registration is success for the URL $returnURLstring \n";
                                       error_log($succMsg, 3, $logFilePath);
                                       unset($succMsg);
                                       $headerURL = $returnURLstring."&".$message;
                                   } else if ($resp['status'] == 'failed'){
                                       $logmsg = $message.$returnURLstring." \n";
                                        error_log($logmsg, 3, $logFilePath);
                                        unset($logmsg);
                                        $headerURL = $returnURLstring."&status=failure&lti_errormsg=".urlencode($message);
                                   }
                                   header('Location: ' . $headerURL);
                                } else {
                                    $eMsg = 'internal error occured during processing the request';
                                    $errLogMsg = "No information is returned back from the toolRegisteration action call \n ";
                                    error_log($errLogMsg, 3, $logFilePath);
                                    unset($errLogMsg);
                                    $headerURL = $returnURL."status=failure&lti_errormsg=".urlencode($eMsg);
                                }
                                
                            } else {
                                $message = "Invalid lti_message_type parameters is passed";
                                // Log the message
                                $logMessage = $message." from the $returnURLPath".". Time : ".date('M-d-Y H:i:s')." \n ";
                                error_log($logMessage, 3, $logFilePath);
                                $returnURL = $returnURL."status=failed&lti_errormsg=".urlencode($message);
                                unset($message);
                                header('Location: ' . $returnURL);
                            }
						
			} else {
                            $message =  "Input parameters are missing"; 
                            // Log the message
                            $logMessage = $message." from the $returnURLPath".". Time : ".date('M-d-Y H:i:s')." \n ";
                            error_log($logMessage, 3, $logFilePath);
                            $returnURL = $returnURL."status=failed&lti_errormsg=".urlencode($message);
                            unset($message);
                            header('Location: ' . $returnURL);
			}
		} else {
                    $message = "Invalid HTTP request"; 
                    // Log the message
                    $logMessage = $message." from the $returnURLPath".". Time : ".date('M-d-Y H:i:s')." \n ";
                    error_log($logMessage, 3, $logFilePath);
                    $returnURL = $returnURL."status=failed&lti_errormsg=".urlencode($message);
                    unset($message);
                    header('Location: ' . $returnURL);
		}
		unset($tpObj);
		ob_end_flush();
?>
