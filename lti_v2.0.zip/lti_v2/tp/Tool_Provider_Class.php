<?php

/**
 * Description of Tool_Provider_Class
 *
 * @author srinivasu
 */

require_once ("../util/lti_util.php");
//require_once ("../tp/Tp_Launch_Lti.php");

function __autoload($class_name) 
{
	//echo $class_name;
	require_once "../library/".$class_name.".php";
    
}


// session_start();
class Tool_Provider_Class {
    //put your code here
    
    public $tpDBObj;
    public $oauthObj;
    public $logFilePath;
    
    // Class constructor method
    public function __construct() {
        $this->tpDBObj = new tpdatabase(); //connection to TP DB
        $this->oauthObj = new OAuthRequest();
        $this->logFilePath = LOG_FILE_PATH;
    }
    
    /**
     * @functionality - Will register TC with the TP.
     * 
     * @param - input [array] $params - Registration posted values. output [string] status (success/failed) as a query string to 
     *  TC defined return URL.
     * 
     * @copyright - (2016) Impelsys India Pvt. Ltd.
     * 
     * @author Srinivasu M <srinivasu.m@impelsys.com>
     */
  
    public function toolRegisteration($postParams = array() ) {

        if(count($postParams) > 0) {
            //echo " Inside the toolRegisteration <pre>"; print_r($postParams); die;
            
            $this->logErrorMessage(" ###### Tool Registration (TR) request initiated from URL '".$_SERVER['HTTP_REFERER']."'");
            
            //variable initialization
            $tcprofileURL = $launchPresentationReturnURL = NULL;
            
            //Validating the mandatory fields
            $postParams = $this->tpDBObj->preventXssArray($postParams);
            $previousUrlPath = $_SERVER['HTTP_REFERER'];
            $validationResp = $this->validateRegistrationValues($postParams,$previousUrlPath);
            
            if($validationResp['status'] == 'failed'){
                $this->logErrorMessage($validationResp['message']);
                $returnArr['status'] = 'failed';
                $returnArr['message'] = $validationResp['message'];
                $returnArr['finalreturnURL'] = $validationResp['finalreturnURL'];
                return $returnArr;
            }
            
            
            $reg_key        = $postParams['reg_key'];
            $reg_password   = $postParams['reg_password'];
            $profileUrl     = $postParams['tc_profile_url'];
            $lti_version    = $postParams['lti_version'];
            $launchPresentationReturnURL = $validationResp['finalreturnURL'];
            
            // To make sure that the same user will not try to register again with the same credentials again.
            
            $secretRespData = NULL;
            $proxyFields 	= array('ltri_id');
            $proxyCondition = " ltri_reg_key ='".$reg_key."' AND ltri_reg_pwd ='".$reg_password."' AND ltri_status != 'F'"; 
            //If validation for reg_key & reg_password is required at domain level then uncomment below line.
            //$proxyCondition .= "AND ltri_tc_req_domain = '".$previousUrlPath."' LIMIT 1 ";
            $secretRespData = $this->tpDBObj->select(LTI_TOOL_REGISTRATION_INFO, $proxyFields, $proxyCondition);
            
            if (isset($secretRespData) && is_array($secretRespData) && $secretRespData['resultCount'] > 0 ) {
                unset($secretRespData);
                $eLogMsg = "Tool registration with the same credentials ( reg_key = ".$reg_key." )already exists.";
                $eMsg = "Tool registration with the same credentials already exists.";
                $this->logErrorMessage($eLogMsg);
                $returnArr['status'] = 'failed';
                $returnArr['message'] = $eMsg;
                $returnArr['finalreturnURL'] = $launchPresentationReturnURL;
                return $returnArr;
            } 
            
            // $reg_key & $reg_password are used to generate the Oauth_signature while posting the TOOL PROVIDER Profile information to the tool consumer.
            $oauth_consumer_key = $reg_key;
            $oauth_consumer_password = $reg_password;
            
            //Check for URL format for passing the LTI_VERSION inthe TC profile URL as a Query String
            $queryString    = parse_url($postParams['tc_profile_url'], PHP_URL_QUERY);
            if($queryString){
                // if URL contains any Query param then append data with '&'
                $tcprofileURL = trim($postParams['tc_profile_url'])."&amp;lti_version=".$lti_version;
            } else {
                // if URL does not contains any Query param then append data with '?'
                $tcprofileURL = trim($postParams['tc_profile_url'])."?lti_version=".$lti_version;
            }
            

            $dts = DATE('Y-m-d H:i:s');
            $insertArray = array(
                'ltri_id'=> '',
                'ltri_tc_req_domain'=>$previousUrlPath, 
                'ltri_reg_key'=>$oauth_consumer_key, 
                'ltri_reg_pwd'=>$oauth_consumer_password, 
                'ltri_tc_return_url'=>$launchPresentationReturnURL, 
                'ltri_profile_url'=>$profileUrl, 
                'ltri_tc_guid'=>NULL,
                'ltri_tool_proxy_guid'=>NULL,
                'ltri_shared_secret'=> NULL,
                'ltri_status'=>'I',
                'ltri_resource_access_level'=>'d',
                'ltri_errror_log'=>NULL,
                'ltri_updated_dts'=>$dts,
                'ltri_created_dts'=>$dts
                ); 
            
            // Insert the information in the tool registration table
            $lastInsertIdVal = $this->tpDBObj->insertDataInToTP(LTI_TOOL_REGISTRATION_INFO,$insertArray);
            $ltri_id = (int) trim($lastInsertIdVal);

            if ($ltri_id > 0) { // TC registration request info started successfully
                
                try {
                    // GET TC Profile Info
                    $tcProfileJSONData = $this->getToolConsumerProfileData($tcprofileURL);
                    $tcProfileArrayData = json_decode($tcProfileJSONData, TRUE);
                    
                    if (is_array($tcProfileArrayData) && count($tcProfileArrayData) > 0 ) {
                       
                        $newToolProxyRegisterURL = $this->checkCapabilitiesServicesOffered($tcProfileArrayData,$ltri_id);
                        
                        
                        if( $newToolProxyRegisterURL['status'] == 'success') {
                            
                            
                            $guid = $tcProfileArrayData['guid'];
                            $this->logErrorMessage("Validation of Capabilities and Services offered completed. GUID - ".$guid);
                            $updateDataGuid['ltri_tc_guid'] = $guid;
                            $updateDataGuid['ltri_tc_post_data_url'] = $newToolProxyRegisterURL['message'];
                            $updateConditionGuid = " ltri_id = ".$ltri_id;
                            $this->tpDBObj->updateData(LTI_TOOL_REGISTRATION_INFO, $updateDataGuid, $updateConditionGuid);
                            
                            $queryString = "?ltri_id=".$ltri_id.'&guid='.$guid;
                            $path = SELECT_CAPABILITIES_URL.$queryString;
                            //$path = SELECT_CAPABILITIES_URL.$ltri_id.'/'.$guid;
                            
                            header("Location: $path");
                        } else {
                            $updateTRTable['ltri_errror_log'] = $newToolProxyRegisterURL['message'];
                            $updateTRTable['ltri_status'] = "F";
                            $updateTRTable['ltri_updated_dts'] = DATE('Y-m-d H:i:s');
                            $toolUpdateCondition = " ltri_id = ".$ltri_id;
                            $this->tpDBObj->updateData(LTI_TOOL_REGISTRATION_INFO, $updateTRTable, $toolUpdateCondition);
                            $this->logErrorMessage($newToolProxyRegisterURL['message']);
                            unset($updateTRTable);
                            return array(
                                'status'=>'failed', 
                                'message'=>$newToolProxyRegisterURL['message'], 
                                'finalreturnURL'=>$launchPresentationReturnURL
                            );
                        }
                    } else {
                        $errmsg_info = 'No information available for tool consumer profile';
                        $updateTable['ltri_errror_log'] = $errmsg_info;
                        $updateTable['ltri_status'] = "F";
                        $updateTable['ltri_updated_dts'] = DATE('Y-m-d H:i:s');
                        $toolRegUpdateCondition = " ltri_id = ".$ltri_id;
                        $this->tpDBObj->updateData(LTI_TOOL_REGISTRATION_INFO, $updateTable, $toolRegUpdateCondition);
                        $this->logErrorMessage($errmsg_info);
                        return array('status'=>'failed', 'message'=>$errmsg_info, 'finalreturnURL'=>$launchPresentationReturnURL);
                        unset($errmsg_info);
                    }
                } catch (Exception $ex) {
                    $message = $ex->getMessage();
                    
                    $updateTableData['ltri_errror_log'] = "'".$message."'";
                    $updateTableData['ltri_status'] = "F";
                    $updateTableData['ltri_updated_dts'] = DATE('Y-m-d H:i:s');
                    $updateToolRegConditionData = " ltri_id = ".trim($ltri_id);
                    $this->tpDBObj->updateData(LTI_TOOL_REGISTRATION_INFO, $updateTableData, $updateToolRegConditionData);
                    $this->logErrorMessage($message);
                    return array('status'=>'failed','message'=>$message, 'finalreturnURL'=>$launchPresentationReturnURL);
                }
            } else {
                return array('status'=>'failed','message'=>"internal error occured during processing the request.", 
                    'finalreturnURL'=>$launchPresentationReturnURL);
            }
        } else {
            return array('status'=>'failed','message'=>"input data is missing", 'finalreturnURL'=>$_SERVER['PHP_REFERER']);
        }
    } 
    
    /**
     * @functionality - Fecth Tool Consumer Profile using HTTP REST GET request.
     * 
     * @param - input [string] $tcprofileURL - TC profile URL. output [JSON-data] TC profile info
     *  
     * @copyright - (2016) Impelsys India Pvt. Ltd.
     * 
     * @author Srinivasu M <srinivasu.m@impelsys.com>
     */
    
    private function getToolConsumerProfileData($tcprofileURL = NULL ) {
        $this->logErrorMessage(" Fetching Tool Consumer profile started. URL : '".$tcprofileURL."'");
        
        if(isset($tcprofileURL)) {
            $ch = curl_init();
            curl_setopt($ch,CURLOPT_URL,$tcprofileURL);
            //if it is set to true, data is returned as string instead of outputting it.
            curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
            curl_setopt($ch,CURLOPT_HTTPAUTH,CURLAUTH_ANY); 
            $output = curl_exec($ch);
            $this->logErrorMessage(" Fetching Tool Consumer profile completed.  URL : '".$tcprofileURL."'");
            if($output === false) {
                throw new Exception("Failed to retrieve tool consumer profile.");
            }
            return $output;
            curl_close($ch);
        }
        return FALSE;
    } 
    
    /**
     * @functionality - Cross verify the Capabilities / Services capture from the TC Profile data.
     * 
     * @param - input [array] $tcProfileArrayData - TC Profile Data. [int] $ltri_id - id of the tool_proxy-registration table id.
     * 
     * @return array Description 
     * 
     * @copyright - (2016) Impelsys India Pvt. Ltd.
     * 
     * @author Srinivasu M <srinivasu.m@impelsys.com>
     */
    
    function checkCapabilitiesServicesOffered($tcProfileArrayData = array(), $ltri_id = NULL) {
		
        //print_r($tcProfileArrayData); die;
        if (is_array($tcProfileArrayData) && count($tcProfileArrayData) > 0 && $ltri_id > 0) {
            
            $guid = $tcProfileArrayData['guid'];
            $this->logErrorMessage("Validation of Capabilities and Services offered started. GUID - ".$guid);
            
            $tcCapabilityOffered    = $tcProfileArrayData['capability_offered'];
            $tcServiceOffered       = $tcProfileArrayData['service_offered'];
            
            $tcCapabilityOffered    = array_map('strtolower',$tcCapabilityOffered);
            
            $capabilitiesMatchingFlag = $servicesOfferedMatchingFlag = FALSE;
            $tcPostURL = NULL;
            
            // CHECKS for SERVICES
            if (count($tcServiceOffered) > 0) {
                $checkForValue = 'application/vnd.ims.lti.v2.toolproxy+json';
                $checkForvalueKey = 'format';
                foreach ( $tcServiceOffered as $soKey => $soVal ) {
                    $searchParamData = $soVal[$checkForvalueKey];
                    if (is_array($searchParamData)){
                        if (in_array($checkForValue, $searchParamData)) {
                            
                            if ( strtoupper($soVal['action'][0]) == 'POST' && count($soVal['action']) == 1 ) {
                                $tcPostURL = $soVal['endpoint'];
                                if (isset($tcPostURL)) {

                                    // CAPTURE THE TC SERVICES DETAILS
                                    $insertTcServicesOffered['lti_tc_services_id'] = NULL;
                                    $insertTcServicesOffered['ltri_id'] = (int) $ltri_id;
                                    $insertTcServicesOffered['lti_tc_services_created_dts'] = DATE('Y-m-d H:i:s');
                                    $serviceInsertCount = $serviceLoopCount  = 0;
                                    foreach ( $tcServiceOffered as $tcsoKey => $tcsoVal ) {
                                        $serviceLoopCount = $serviceLoopCount+1;
                                        $insertTcServicesOffered['lti_tc_services_type'] = $tcsoVal['@type'];
                                        $insertTcServicesOffered['lti_tc_services_id_val'] = $tcsoVal['@id'];
                                        $insertTcServicesOffered['lti_tc_services_endpoint'] = $tcsoVal['endpoint'];
                                        $formatString = implode(' # ', $tcsoVal['format']);
                                        $actionString = implode(' & ', $tcsoVal['action']);
                                        $insertTcServicesOffered['lti_tc_services_format'] = $formatString;
                                        $insertTcServicesOffered['lti_tc_services_action'] = $actionString;
                                        $insertTcServicesOffered = $this->tpDBObj->preventXssArray($insertTcServicesOffered);
                                        $servicesInsertId = $this->tpDBObj->insertDataInToTP(LTI_TOOLCONSUMER_SERVICES, $insertTcServicesOffered);
                                        if($servicesInsertId > 0){
                                            $serviceInsertCount = $serviceInsertCount+1;
                                        }
                                    }
                                    // all the services information inserted successfully
                                    if($serviceInsertCount == count($tcServiceOffered)){

                                        // CHECKS for CAPABILITIES
                                        if (count($tcCapabilityOffered) > 0) {

                                            $tableFields = array('capability_name','capability_id','capability_mandatory');
                                            $capabilityCond = 'capability_status = '.LTI_ACTIVE;
                                            $dbCapabilitiesList= $this->tpDBObj->select(LTI_CAPABILITIES, $tableFields, $capabilityCond);
                                            if(isset($dbCapabilitiesList) && $dbCapabilitiesList['resultCount'] > 0 ) {

                                                $capabilityNameList = array();
                                                $capabilityMandatoryArray = array();
                                                foreach($dbCapabilitiesList['result'] as $k=>$v){
                                                    if($v['capability_mandatory'] == 1){
                                                        $capabilityMandatoryArray[] = $v['capability_name'];
                                                    } else {
                                                        $capabilityNameList[] = $v['capability_name'];
                                                        $capabilityIDList[$v['capability_name']] = $v['capability_id'];
                                                    }
                                                    
                                                }
                                                // Below condition checks whether the mandatory capabilities are defined by TC or not in his profile.
                                                $notExists = 0;
                                                for($i=0; $i < count($capabilityMandatoryArray); $i++){
                                                    if(!in_array($capabilityMandatoryArray[$i],$tcCapabilityOffered)){
                                                        $notExists = $notExists+1;
                                                    }
                                                }
                                                if($notExists > 0){
                                                   return array('status'=>'failed','message'=>"mandatory capabilites are not defined in the tool consumer profile data"); 
                                                }
                                                
                                                $capabilitiesDifference = array_intersect($capabilityNameList, $tcCapabilityOffered);
                                                //Currently NOT REQUIRED 
                                                //$extraCapabilitiesFromTC = array_diff($tcCapabilityOffered,$capabilityNameList);

                                                // check atleast one capabilities is matching
                                                if (count($capabilitiesDifference) > 0) {

                                                    // CAPTURE THE TOOL CONSUMER DEFINED CAPABILITES
                                                    $tcCapabilitiesInsertArr = array();
                                                    $tcCapabilitiesInsertArr['lti_tc_capability_id']    = NULL;
                                                    $tcCapabilitiesInsertArr['ltri_id'] = (int) $ltri_id;
                                                    $tcCapabilitiesInsertArr['lti_tc_capability_insert_dts'] = DATE('Y-m-d H:i:s');
                                                    $loopCount = $insertCount = 0;
                                                    foreach($tcCapabilityOffered AS $k1 => $v1 ){
                                                        $loopCount = $loopCount+1;
                                                        $tcCapabilitiesInsertArr['capability_id'] = (int) $capabilityIDList[$v1];
                                                        $tcCapabilitiesInsertArr = $this->tpDBObj->preventXssArray($tcCapabilitiesInsertArr);
                                                        $insertId = $this->tpDBObj->insertDataInToTP(LTI_TOOLCONSUMER_CAPABILITIES, $tcCapabilitiesInsertArr);
                                                        if($insertId > 0){
                                                            $insertCount = $insertCount+1;
                                                        }
                                                    }

                                                    if ($insertCount == $loopCount) {
                                                         return array('status'=>'success','message'=>$tcPostURL);
                                                    }
                                                } else {
                                                    return array('status'=>'failed','message'=>'Invalid Capabilities defined');
                                                }
                                            }
                                        } else {
                                            return array('status'=>'failed','message'=>'Capabilities information is not defined');
                                        }
                                    }
                                } else {
                                    return array('status'=>'failed','message'=>'Post request to Tool Consumer URL path not defined.');
                                }
                            } else {
                                return array('status'=>'failed','message'=>"POST Method not found for application/vnd.ims.lti.v2.toolproxy+json in order to do tool_registration"); 
                            }
                        } else {
                            return array('status'=>'failed','message'=>"Must have an application/vnd.ims.lti.v2.toolproxy+json service available in order to do tool_registration");
                        }
                    }
                }
            } else {
                return array('status'=>'failed','message'=>'Services offered are not defined');
            }
        }
        return array('status'=>'failed','message'=>'Input params are missing in Capabilities and Services');
    }
    
   /*
    * This is the function which will be posting the TP Profile data to the TC after 
    * TC selected all access level value & resources details in the tool registration process.
    * 
    * @params : input int - $ltriId (PK) from table "lti_tool_registration_info"
    */
    function postToolProxyRegistrationToConsumer($ltriId = NULL){
		
        if($ltriId > 0){
            $fields = array('ltri_id', 'ltri_tc_post_data_url','ltri_reg_key','ltri_reg_pwd','ltri_tc_return_url','ltri_tc_req_domain',
                'ltri_status');
            $condition = " ltri_id ='".$ltriId."' AND ltri_status ='I' ";
            $toolConsumerData = $this->tpDBObj->select(LTI_TOOL_REGISTRATION_INFO, $fields, $condition);
            
            // DELETE THIS, // generate the tool provide data dynamically
            $tpFields = array('tp_content_data');
            $tpCondition = " tp_content_id = 1 ";
            $toolProviderData = $this->tpDBObj->select(LTI_TP_CONTENT, $tpFields, $tpCondition);
            $tpBodyContent = trim($toolProviderData['result'][0]['tp_content_data']);
            // DELETE THIS  above line
            
            
            if(isset($toolConsumerData) && $toolConsumerData['status'] == 'success' && $toolConsumerData['resultCount'] > 0 ){
                $consumerData = $toolConsumerData['result'][0];
                $postDataToURL = trim($consumerData['ltri_tc_post_data_url']);
                $ltri_id = trim($consumerData['ltri_id']);
                $cosumerKey = trim($consumerData['ltri_reg_key']);
                $consumerPassword = trim($consumerData['ltri_reg_pwd']);
                $finalReturnURL = trim($consumerData['ltri_tc_return_url']);
                
                if(!isset($finalReturnURL)){
                    $finalReturnURL = trim($consumerData['ltri_tc_req_domain']);
                }
                
                
                try{
                    unset($_SESSION['reg_key']);
                    unset($_SESSION['reg_password']);
                    $_SESSION['reg_key']        = $cosumerKey;
                    $_SESSION['reg_password']   = $consumerPassword;
                    $headerResponseStringData = array();
                    $headerResponseStringData = sendOAuthBody("POST", $postDataToURL, $cosumerKey, $consumerPassword, "application/vnd.ims.lti.v2.toolproxy+json", $tpBodyContent);
                    //echo "<pre>";print_r($headerResponseStringData); die; 
                    $this->logErrorMessage($headerResponseStringData);

                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_HEADER,true);
                    curl_setopt($ch, CURLOPT_HTTPHEADER,array($headerResponseStringData));
                    curl_setopt($ch, CURLOPT_URL, $postDataToURL);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $tpBodyContent);
                    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
                    curl_setopt($ch, CURLOPT_POST, TRUE);

                    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false); curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                    $proxyRegistrationResp = curl_exec($ch);

                    $curlGetInfo = curl_getinfo($ch);
                    curl_close($ch);

                    $curlData =  array('status'=>'success','message'=>$proxyRegistrationResp, 'curlGetInfo'=>$curlGetInfo);                                 
                    $callResp = $this->processCurlReturnData($curlData, $ltriId);
                    if($callResp['status'] == 'success'){
                        return array('status'=>'success','message'=>$callResp['message'],'returnURL'=>$finalReturnURL);
                    } else {
                        $errmsgs = "status=failure&amp;lti_errormsg=".urlencode($callResp['message']);
                        return array('status'=>'failure','message'=>$errmsgs,'returnURL'=>$finalReturnURL);
                    }
                    
                } catch(OAuthException $E) {
                    //echo "Response: ". $E->lastResponse . "";
                    $curlerrData =  array('status'=>'failed','message'=>$E->lastResponse);
                    $responsedata = $this->processCurlReturnData($curlData,$ltriId);
                    $errmsgs = "status=failure&amp;lti_errormsg=".urlencode($responsedata['message']);
                    return array('status'=>'failure','message'=>$errmsgs,'returnURL'=>$finalReturnURL);
                }
            } else {
                $errormssg = "no records found for the requested id";
                $this->logErrorMessage("No records found for the requested id : $ltriId");
                $errmsgs = "status=failure&amp;lti_errormsg=".urlencode($errormssg);
                return array('status'=>'failure','message'=>$errmsgs,'returnURL'=>'');
            }
        } else {
			$this->logErrorMessage("input params are missing in postToolProxyRegistrationToConsumer function call (internal error)");
            $msgdata = "status=failure&amp;lti_errormsg=".urlencode("internal error");
            return array('status'=>'failure','message'=>$msgdata,'returnURL'=>'');
        }
    }
    
    /**
     * @functionality process the CURL return data. 
     * This curl data is when the tool consumer sends back the tool_proxy_guid when TP posted his profile data.
     * 
     * @param (array) $curlDataArray
     * 
     * @param (int) $ltriId
     * 
     * @return array
     * 
     * @copyright (c) 2016, Impelsys India Pvt. Ltd. 
     * 
     * @author Srinivasu M <srinivasu.m@impelsys.com>
     */
    function processCurlReturnData($curlDataArray = array(), $ltriId = NULL) {
		
        if(is_array($curlDataArray['curlGetInfo']) && count($curlDataArray['curlGetInfo']) > 0 && $curlDataArray['status'] == 'success' && $ltriId > 0)
        {
            // HTTP_CODE 201 indicates that the TC accepted (created) the TP Profile in his end.
            if ($curlDataArray['curlGetInfo']['http_code'] == 201 ) {
                $replyStatus = "success";
                $tool_proxy_guidArray = explode('tool_proxy_guid',$curlDataArray['message']);
                $tool_proxy_guidData = explode("}",$tool_proxy_guidArray[1]);
                $tool_guid = str_replace(array('":', '}','"'),'',$tool_proxy_guidArray[1]);

                $dtsVal = date('Y-m-d H:i:s');
                $finalUpdateData['ltri_updated_dts'] = $dtsVal;
                if($tool_guid) {
                    $finalUpdateData['ltri_tool_proxy_guid'] = $tool_guid;
                    $finalUpdateData['ltri_status'] = "S";
                } else {
                    $finalUpdateData['ltri_status'] = "F";
                    $finalUpdateData['ltri_errror_log'] = 'Tool proxy guid not found';
                }
                $updateCondition = " ltri_id = ".$ltriId;
                $updatedData = $this->tpDBObj->updateData(LTI_TOOL_REGISTRATION_INFO, $finalUpdateData, $updateCondition);
                if($updatedData) {
                    $urlparameters = "status=".$replyStatus."&tool_guid=".$tool_guid;
                    $this->logErrorMessage("Tool Registration process completed successfully. ");
                    return array('status'=>'success','message'=>$urlparameters);
                }
            } else {
				
                $msg = $curlDataArray['curlGetInfo']['http_code'];
                $updateToolRegTableData['ltri_errror_log'] = $msg." :: ".$curlDataArray['message'];
                $updateToolRegTableData['ltri_status'] = "F";
                $updateConditionData = " ltri_id = ".$ltriId;
                $this->tpDBObj->updateData(LTI_TOOL_REGISTRATION_INFO, $updateToolRegTableData, $updateConditionData);
                $this->logErrorMessage($msg);
                return array('status'=>'failed','message'=>$msg);
            }
        } else if($ltriId == 0 ){
            $this->logErrorMessage($errMsg);
            return array('status'=>'failed','message'=>$errMsg);
        } else {
            $updateErrrTableData['ltri_errror_log'] = $curlDataArray['message'];
            $updateErrrTableData['ltri_status'] = "F";
            $updateErrrConditionData = " ltri_id = ".$ltriId;
            $this->tpDBObj->updateData(LTI_TOOL_REGISTRATION_INFO, $updateErrrTableData, $updateErrrConditionData);
            $this->logErrorMessage($curlDataArray['message']);
            return array('status'=>'failed','message'=>$curlDataArray['message']);
        }
        
    }
    
    /**
     * @functionality - Launch the resource
     * 
     */
   
    public function toolLaunchRequest($params = array(), $resourceName = NULL) {
	// log the input params & resource name.
        $this->logErrorMessage(" #### Tool launch request initiated. ");
        $this->logErrorMessage(" Input parameters : $params :: resource-name : $resourceName. ");
        if(count($params) > 0 && isset($resourceName)) {
            global $basestring;
            
            // Filter the input array with empty values.
            $getPostedArrayKeyValues = $this->simplifyPostValues($params);

            // STEP-1 Check for Mandatory OAuth-key
            if(!array_key_exists('lti_version',$getPostedArrayKeyValues) && !isset($getPostedArrayKeyValues['lti_version'])) {
                $this->logErrorMessage("LTI version is missing from request - '".$_SERVER['HTTP_REFERER']."'");
                return array('status'=>'failure','message'=>'LTI version is missing');
            } if(isset($getPostedArrayKeyValues['lti_version']) && strtolower($getPostedArrayKeyValues['lti_version']) != LTI_VERSION){
                $this->logErrorMessage("LTI version (".LTI_VERSION.") is invalid from request '".$_SERVER['HTTP_REFERER']."'");
                return array('status'=>'failure','message'=>'LTI version is invalid');
            }
            
            if(!array_key_exists('resource_link_id',$getPostedArrayKeyValues) && !isset($getPostedArrayKeyValues['resource_link_id'])) {
                $this->logErrorMessage("Resource link id is missing from request - '".$_SERVER['HTTP_REFERER']."'");
                return array('status'=>'failure','message'=>'Resource link id is missing');
            }
            
            if(array_key_exists('oauth_consumer_key',$getPostedArrayKeyValues)) {
                //CHECK FOR OAUTH PARAM is missing
                if(empty($getPostedArrayKeyValues['oauth_signature']))
                {  
                    $this->logErrorMessage("OAuth Signature is missing - '".$getPostedArrayKeyValues['oauth_consumer_key']."'");
                    return array('status'=>'failure','message'=>'OAuth Signature is missing');
                }
                    
                // STEP-2 Get Shared Secret using oauth_conusmer_key
                $OAuthConsumerKey = $getPostedArrayKeyValues['oauth_consumer_key'];
                $checkFilds = array('ltri_shared_secret','ltri_id','ltri_resource_access_level');
                $checkCondition = " ltri_tool_proxy_guid ='".$OAuthConsumerKey."'";
                
                $sharedSecretId = $this->tpDBObj->select(LTI_TOOL_REGISTRATION_INFO, $checkFilds, $checkCondition);
                if(isset($sharedSecretId) && is_array($sharedSecretId) &&  $sharedSecretId['resultCount'] > 0 && $sharedSecretId['status'] == 'success' ) {
                    
                    $information = $sharedSecretId['result'][0];
                    $sharedSecredValue = $information['ltri_shared_secret'];
                    $ltiConsumerAccessLevel = $information['ltri_resource_access_level'];
                    $ltriId = $information['ltri_id'];
                    
                    // chect whether provided resource (in the launch url) is valid or not by checking from lti_resource_info table
                    $tableFlds = array(LTI_RESOURCE_INFO_REQ_ROLE, LTI_RESOURCE_INFO_UNIQ_ID, LTI_RESOURCE_INFO_ID);
                    $tableCond = LTI_RESOURCE_INFO_UNIQ_ID." = '".$resourceName."' AND ".LTI_RESOURCE_INFO_STATUS ." = ".LTI_ACTIVE;
                    $resourceIntValueResp = $this->tpDBObj->select(LTI_RESOURCE_INFO, $tableFlds, $tableCond);
                    //echo "<pre>"; print_r($resourceIntValueResp); die;
                    $ltiResourceInfoPK = 0;
                    if(is_array($resourceIntValueResp) && isset($resourceIntValueResp) && $resourceIntValueResp['resultCount'] > 0 && $resourceIntValueResp['status'] == 'success'){

                        $resourceInfo = $resourceIntValueResp['result'][0];
                        //The below line is like, does this resource required role access level authentication or not
                        $resourceInfoRequiredRole = $resourceInfo[LTI_RESOURCE_INFO_REQ_ROLE]; 
                        $ltiResourceInfoPK = (int) $resourceInfo[LTI_RESOURCE_INFO_ID]; 
                    } else {
                       return array('status'=>'failure','message'=>'Invalid resource link.'); 
                    }
                        
                    if($ltiConsumerAccessLevel == 'd'){
                        // do nothing
                    } else if ($ltiConsumerAccessLevel == 's' || $ltiConsumerAccessLevel == 'm') {
                        // validate url
                        
                        // CHECK FOR SPECIFIC RESOURCE ACCESS's
                        $linkLevelAccessFldsArr = array('lti_link_level_access_id');
                        $linkLevelAccessConditionCheck = " lti_resource_info_uniq_id = '".$resourceName."' AND ltri_id = ".$ltriId;
                        $linkLevelAccessCheck = $this->tpDBObj->select(LTI_LINK_LEVEL_ACCESS, $linkLevelAccessFldsArr, $linkLevelAccessConditionCheck);

                        if ($linkLevelAccessCheck['status'] == 'success' && $linkLevelAccessCheck['resultCount'] == 0) {
                            return array('status'=>'failure','message'=>'Do not have access to the requested resources.');
                        }
                    }
                        
                        $store = new TrivialOAuthDataStore();
                        $store->add_consumer($OAuthConsumerKey, $sharedSecredValue);
                        $server = new OAuthServer($store);
                        $method = new OAuthSignatureMethod_HMAC_SHA1();
                        $server->add_signature_method($method);
                        $request = OAuthRequest::from_request();
                        $basestring = $request->get_signature_base_string();
                        $this->logErrorMessage("OAuth Signature verification process started. OAuthConsumerKey : '".$OAuthConsumerKey."' & resource id - '".$resourceName."'");
                        
                        try {
                            // Oauth validation checks here,
                            $server->verify_request($request); 
                            $this->valid = true;
                            $this->logErrorMessage("OAuth Signature verification is success. OAuthConsumerKey : '".$OAuthConsumerKey."' & resource id - '".$resourceName."'");
                            
                            //STEP-5  validate roles (optional)
                            
                            if(isset($getPostedArrayKeyValues['roles'])) {
                                $tcDefinedRoleName = $getPostedArrayKeyValues['roles'];
                                
                                $rolesFields = array('lti_user_role_name','lti_user_role_urn_name');
                                $rolesCondition = " lti_user_role_status = ".LTI_ACTIVE;
                                $preDefinedRolesArray = $this->tpDBObj->select(LTI_USER_ROLE, $rolesFields, $rolesCondition);
                                
                                if (is_array($preDefinedRolesArray) && $preDefinedRolesArray['resultCount'] > 0 && $preDefinedRolesArray['status'] == 'success') {
                                    
                                    foreach ($preDefinedRolesArray['result'] as $rolesKey => $rolesVal) {
                                        $preDefinedRoles[] = $rolesVal['lti_user_role_name'];
                                        $preDefinedRoles[] = $rolesVal['lti_user_role_urn_name'];
                                    }
                                }
                                
                                $formRoles = strtolower($tcDefinedRoleName);
                                $formRolesToArr = explode(",", $formRoles);
                                $rolesArrCount = count($formRolesToArr);
                                $error = 0;
                                
                                //STEP-6  validate roles (optional) & exists with in the system
                                if($rolesArrCount > 1){
                                    for ($aLoop = 0; $aLoop < $rolesArrCount; $aLoop++){
                                        if(!in_array($formRolesToArr[$aLoop], $preDefinedRoles)) {
                                            $error = $error+1;
                                        }
                                    }
                                } else {
                                    if(!in_array($formRolesToArr[0], $preDefinedRoles)) {
                                        $error = $error+1;
                                    }
                                }
                                
                                if($error > 0){
                                    $this->logErrorMessage("Invalid User Roles defined. OAuthConsumerKey : '".$OAuthConsumerKey."'");
                                    return array('status'=>'failure','message'=>'Invalid User Roles defined');
                                }
                                
                            // VALIDATE THE RESOURCE HANDLERS BASED ON THE ROLES                                
                                $resourceAccessFlag = TRUE;
                                if($resourceInfoRequiredRole == 1){
                                    $resourceAccessFlag = $this->validateResourceHandlers($resourceName,$tcDefinedRoleName, $OAuthConsumerKey, $ltiResourceInfoPK);
                                }

                               if (!$resourceAccessFlag) { 
                                   $this->logErrorMessage("Resource not available for the defined role. OAuthConsumerKey : '".$OAuthConsumerKey."'");
                                   return array('status'=>'failure','message'=>'resource not available for the defined role');
                               }
                               $this->logErrorMessage("Access permissions to Resources based on role validation completed. OAuthConsumerKey : '".$OAuthConsumerKey."' and resource id : '".$resourceName."'");
                            }
                            
                            
                            //STEP-7  Capture form values into the DATABASE
                            
                            $this->logErrorMessage("Launch request data insertion into the table started. OAuthConsumerKey : '".$OAuthConsumerKey."'");
                            
                            $lastInsertId = $this->insertDataIntoLaunchRequest( $getPostedArrayKeyValues, $ltriId);

                            if($lastInsertId){
                                $callBackURL = $getPostedArrayKeyValues['launch_presentation_return_url'];
                                return array('status'=>'launch','message'=>'Success', 'callBackURL'=>$callBackURL,'resourceAccessLevel'=>$ltiConsumerAccessLevel);
                            } else {
                                $this->logErrorMessage("Launch request data insertion into the table failed. Resource id : '".$resourceName."'");
                                return array('status'=>'failure','message'=>'Unexpected error occured during processing');
                            }
                        } catch (Exception $e) {
                            $this->message = $e->getMessage();
                            $this->logErrorMessage($this->message);
                            return array('status'=>'failure','message'=>$this->message);
                        }
                   
                } else {
                    $this->logErrorMessage("Invalid OAuth Consumer Key. '".$_SERVER['HTTP_REFERER']."'");
                    return array('status'=>'failure','message'=>'Invalid OAuth Consumer Key');
                }
                
            } else {
                $this->logErrorMessage("OAuth Consumer Key is missing. '".$_SERVER['HTTP_REFERER']."'");
                return array('status'=>'failure','message'=>'OAuth Consumer Key is missing');
            }
        
        } 
        return array('status'=>'failure','message'=>'input data is missing.');
        
    }

    public function insertDataIntoLaunchRequest( $getPostedArrayKeyValues = array(), $ltriId = NULL ){
        // Return value initialization
        $lastInsertId = 0;
        
        $launchReqDetails['lti_tc_launch_id'] = NULL;
        $launchReqDetails['ltri_id'] = $ltriId;
        
        $launchReqDetails['lti_tc_launch_context_id'] = (isset($getPostedArrayKeyValues['context_id'])) ? $getPostedArrayKeyValues['context_id'] : NULL;
        
        $launchReqDetails['lti_tc_launch_context_label'] = (isset($getPostedArrayKeyValues['context_label'])) ? $getPostedArrayKeyValues['context_label'] : NULL;
        
        $launchReqDetails['lti_tc_launch_context_title'] = (isset($getPostedArrayKeyValues['context_title'])) ? $getPostedArrayKeyValues['context_title'] : NULL;
        
        $launchReqDetails['lti_tc_launch_context_type'] = (isset($getPostedArrayKeyValues['context_type'])) ? $getPostedArrayKeyValues['context_type'] : NULL;
        
        $launchReqDetails['lti_tc_launch_presentation_css_url'] = (isset($getPostedArrayKeyValues['launch_presentation_css_url'])) ? $getPostedArrayKeyValues['launch_presentation_css_url'] : NULL;
        
        $launchReqDetails['lti_tc_launch_presentation_document_target'] = (isset($getPostedArrayKeyValues['launch_presentation_document_target'])) ? $getPostedArrayKeyValues['launch_presentation_document_target'] : NULL;
        
        $launchReqDetails['lti_tc_launch_presentation_locale'] = (isset($getPostedArrayKeyValues['launch_presentation_locale'])) ? $getPostedArrayKeyValues['launch_presentation_locale'] : NULL;
        
        $launchReqDetails['lti_tc_launch_presentation_return_url'] = (isset($getPostedArrayKeyValues['launch_presentation_return_url'])) ? $getPostedArrayKeyValues['launch_presentation_return_url'] : NULL;
        
        $launchReqDetails['lti_tc_launch_lis_outcome_service_url'] = (isset($getPostedArrayKeyValues['lis_outcome_service_url'])) ? $getPostedArrayKeyValues['lis_outcome_service_url'] : NULL;
        
        $launchReqDetails['lti_tc_launch_lis_person_name_family'] =  (isset($getPostedArrayKeyValues['lis_person_name_family'])) ? $getPostedArrayKeyValues['lis_person_name_family'] : NULL;
        
        $launchReqDetails['lti_tc_launch_lis_person_name_full'] = (isset($getPostedArrayKeyValues['lis_person_name_full']))? $getPostedArrayKeyValues['lis_person_name_full'] : NULL;
        
        $launchReqDetails['lti_tc_launch_lis_person_name_given'] = (isset($getPostedArrayKeyValues['lis_person_name_given'])) ? $getPostedArrayKeyValues['lis_person_name_given'] : NULL;
        
        $launchReqDetails['lti_tc_launch_lis_person_sourcedid'] =  (isset($getPostedArrayKeyValues['lis_person_sourcedid'])) ? $getPostedArrayKeyValues['lis_person_sourcedid'] : NULL;
        
        $launchReqDetails['lti_tc_launch_lis_result_sourcedid'] = (isset($getPostedArrayKeyValues['lis_result_sourcedid'])) ? $getPostedArrayKeyValues['lis_result_sourcedid'] : NULL;
        
        $launchReqDetails['lti_tc_launch_lti_version'] = (isset($getPostedArrayKeyValues['lti_version'])) ? $getPostedArrayKeyValues['lti_version'] : NULL;
        
        $launchReqDetails['lti_tc_launch_oauth_callback'] = (isset($getPostedArrayKeyValues['oauth_callback'])) ? $getPostedArrayKeyValues['oauth_callback'] : NULL;
        
        $launchReqDetails['lti_tc_launch_oauth_consumer_key'] = (isset($getPostedArrayKeyValues['oauth_consumer_key'])) ? $getPostedArrayKeyValues['oauth_consumer_key'] : NULL;
        
        $launchReqDetails['lti_tc_launch_oauth_nonce'] = (isset($getPostedArrayKeyValues['oauth_nonce'])) ? $getPostedArrayKeyValues['oauth_nonce'] : NULL;
        
        $launchReqDetails['lti_tc_launch_oauth_signature'] = (isset($getPostedArrayKeyValues['oauth_signature'])) ? $getPostedArrayKeyValues['oauth_signature'] : NULL;
        
        $launchReqDetails['lti_tc_launch_oauth_signature_method'] = (isset($getPostedArrayKeyValues['oauth_signature_method'])) ? $getPostedArrayKeyValues['oauth_signature_method'] : NULL;
        
        $launchReqDetails['lti_tc_launch_oauth_timestamp'] = (isset($getPostedArrayKeyValues['oauth_timestamp'])) ? $getPostedArrayKeyValues['oauth_timestamp'] : NULL;
        
        $launchReqDetails['lti_tc_launch_oauth_version'] = (isset($getPostedArrayKeyValues['oauth_version'])) ? $getPostedArrayKeyValues['oauth_version'] : NULL;
        
        $launchReqDetails['lti_tc_launch_resource_link_description'] = (isset($getPostedArrayKeyValues['resource_link_description'])) ? $getPostedArrayKeyValues['resource_link_description'] : NULL;
        
        $launchReqDetails['lti_tc_launch_resource_link_id'] = (isset($getPostedArrayKeyValues['resource_link_id'])) ? $getPostedArrayKeyValues['resource_link_id'] : NULL;
        
        $launchReqDetails['lti_tc_launch_resource_link_title'] = (isset($getPostedArrayKeyValues['resource_link_title'])) ? $getPostedArrayKeyValues['resource_link_title'] : NULL;
        
        $launchReqDetails['lti_tc_launch_roles'] = (isset($getPostedArrayKeyValues['roles'])) ? $getPostedArrayKeyValues['roles'] : NULL;
        
        $launchReqDetails['lti_tc_launch_tc_info_product_family_code'] = (isset($getPostedArrayKeyValues['tool_consumer_info_product_family_code'])) ? $getPostedArrayKeyValues['tool_consumer_info_product_family_code'] : NULL;
        
        $launchReqDetails['lti_tc_launch_tc_info_version'] = (isset($getPostedArrayKeyValues['tool_consumer_info_version'])) ? $getPostedArrayKeyValues['tool_consumer_info_version'] : NULL;
        
        $launchReqDetails['lti_tc_launch_tc_instance_contact_email'] =  (isset($getPostedArrayKeyValues['tool_consumer_instance_contact_email'])) ? $getPostedArrayKeyValues['tool_consumer_instance_contact_email'] : NULL;
        
        $launchReqDetails['lti_tc_launch_tc_instance_description'] = (isset($getPostedArrayKeyValues['tool_consumer_instance_description'])) ? $getPostedArrayKeyValues['tool_consumer_instance_description'] : NULL;
        
        $launchReqDetails['lti_tc_launch_tc_instance_guid'] = (isset($getPostedArrayKeyValues['tool_consumer_instance_guid'])) ? $getPostedArrayKeyValues['tool_consumer_instance_guid'] : NULL;
        
        $launchReqDetails['lti_tc_launch_user_id'] = (isset($getPostedArrayKeyValues['user_id'])) ? $getPostedArrayKeyValues['user_id'] : NULL;
        $launchReqDetails['lti_tc_launch_user_image'] = (isset($getPostedArrayKeyValues['user_image'])) ? $getPostedArrayKeyValues['user_image'] : NULL;
        
        $launchReqDetails['lti_tc_launch_lis_person_contact_email_primary'] = (isset($getPostedArrayKeyValues['lis_person_contact_email_primary'])) ? $getPostedArrayKeyValues['lis_person_contact_email_primary'] : NULL;
        
        $launchReqDetails['lti_tc_launch_lis_course_offering_sourcedid'] = (isset($getPostedArrayKeyValues['lis_course_offering_sourcedid'])) ? $getPostedArrayKeyValues['lis_course_offering_sourcedid'] : NULL;
        
        $launchReqDetails['lti_tc_launch_lis_course_section_sourcedid'] = (isset($getPostedArrayKeyValues['lis_course_section_sourcedid'])) ? $getPostedArrayKeyValues['lis_course_section_sourcedid'] : NULL;
        
        $launchReqDetails['lti_tc_launch_tc_instance_name'] = (isset($getPostedArrayKeyValues['tool_consumer_instance_name'])) ? $getPostedArrayKeyValues['tool_consumer_instance_name'] : NULL;
        
        $launchReqDetails['lti_tc_launch_tc_instance_url'] = (isset($getPostedArrayKeyValues['tool_consumer_instance_url'])) ? $getPostedArrayKeyValues['tool_consumer_instance_url'] : NULL;
        
        $launchReqDetails['lti_tc_launch_insert_dts'] = DATE('Y-m-d H:i:s');

        $launchReqDetails = $this->tpDBObj->preventXssArray($launchReqDetails);
        
        $lastInsertId = $this->tpDBObj->insertDataInToTP(LTI_TC_LAUNCH_DETAILS, $launchReqDetails);
        $this->logErrorMessage("Launch request data insertion into the table completed. ");
        return $lastInsertId;
    }
    
    /**
     * 
     * @param string $resourceName
     * @param string $tcDefinedRoleName
     * @param string $OAuthConsumerKey
     * @return boolean
     * 
     */
    
    public function validateResourceHandlers($resourceName = NULL,$tcDefinedRoleName = NULL, $OAuthConsumerKey =NULL, $ltiResourceInfoPK=NULL)
    {
        if ($resourceName && $tcDefinedRoleName && $ltiResourceInfoPK > 0) {
            
            $this->logErrorMessage("Access permissions to Resources based on role validation started. OAuthConsumerKey : '".$OAuthConsumerKey. "' and Resource id : '".$resourceName."'");
            $roleID = NULL;
            $RequiredRoleFlag = FALSE;
            
            $tcDefinedRoleNameArr = explode(",", $tcDefinedRoleName);
            if (count($tcDefinedRoleNameArr) > 1 ) {
                // Multiple roles are defined
                $successcount = $errorCount = 0;
                for($c = 0; $c < count($tcDefinedRoleNameArr); $c++ ) {
                    $roleName = rtrim($tcDefinedRoleNameArr[$c],",");
                    // GET THE LTI_ROLE_ID using role name
                    $roleCondition = " lti_user_role_name = '".$roleName."' OR lti_user_role_urn_name = '".$roleName."'";
                    $roleFields = array('lti_user_role_id');
                    $roleRespArr = $this->tpDBObj->select(LTI_USER_ROLE, $roleFields, $roleCondition);
                    if(is_array($roleRespArr) && $roleRespArr['resultCount'] > 0 && $roleRespArr['status'] == 'success') {
                        $roleID = $roleRespArr['result'][0]['lti_user_role_id'];
                    }

                    // GET THE Tool Provider USER ROLE for checking the resource access to the role id
                    if(TP_ROLES == 'yes') {
                        if($roleID > 0){
                            $ltiAccessRoleFields = array(TP_USER_ROLE_ID);
                            $ltiAccessRoleCondition =  LTI_USER_ROLE_ID." = ". $roleID;
                            $ltiAccessRoleRespArr = $this->tpDBObj->select(LTI_ACCESS_ROLES, $ltiAccessRoleFields, $ltiAccessRoleCondition);
                            if(is_array($ltiAccessRoleRespArr) && $ltiAccessRoleRespArr['resultCount'] > 0 && $ltiAccessRoleRespArr['status'] == 'success'){
                                foreach($ltiAccessRoleRespArr['result'] as $ltiAccessRoleRespArrKey => $ltiAccessRoleRespArrVal) {
                                    $cdpRoleIds[] = $ltiAccessRoleRespArrVal[TP_USER_ROLE_ID];
                                }
                            }

                            // $cdpRoleIds contains the CDP roles which are mapped to specific course/resource
                            //$accessResp = $this->checkResourceWithRole($roleName, $resourceId);
                            $accessResp = $this->checkAccessToResource($cdpRoleIds, $resourceName, $ltiResourceInfoPK);
                            if($accessResp){
                                $successcount = $successcount+1;
                            } else {
                                $errorCount = $errorCount+1;
                            }
                        }else {
                            return false;
                        }
                    } else {
                        $errorCount = 0;
                    } 
                }
                if ($errorCount > 0) {
                    return false;
                } else {
                    return true;
                }
            } else if( count($tcDefinedRoleNameArr) == 1) {
                // single role defined.
                $roleName = rtrim($tcDefinedRoleNameArr[0],",");
                // GET THE LTI_ROLE_ID using role name
                $roleCondition = " lti_user_role_name = '".$roleName."' OR lti_user_role_urn_name = '".$roleName."'";
                $roleFields = array('lti_user_role_id');
                $roleRespArr = $this->tpDBObj->select(LTI_USER_ROLE, $roleFields, $roleCondition);
                if(is_array($roleRespArr) && $roleRespArr['resultCount'] > 0 && $roleRespArr['status'] == 'success') {
                    $roleID = $roleRespArr['result'][0]['lti_user_role_id'];
                }

                // GET THE Tool Provider USER ROLE for checking the resource access to the role id
                 if(TP_ROLES == 'yes') {
                    if($roleID > 0){
                        $ltiAccessRoleCondition =  LTI_USER_ROLE_ID." = ". $roleID;
                        $ltiAccessRoleFields = array(TP_USER_ROLE_ID);
                        $ltiAccessRoleRespArr = $this->tpDBObj->select(LTI_ACCESS_ROLES, $ltiAccessRoleFields, $ltiAccessRoleCondition);
                        if(is_array($ltiAccessRoleRespArr) && $ltiAccessRoleRespArr['resultCount'] > 0 && $ltiAccessRoleRespArr['status'] == 'success'){
                            foreach($ltiAccessRoleRespArr['result'] as $$ltiAccessRoleRespArrKey => $ltiAccessRoleRespArrVal) {
                                $cdpRoleIds[] = $ltiAccessRoleRespArrVal[TP_USER_ROLE_ID];
                            }
                        } else {
                            return false;
                        }
                        // $cdpRoleIds contains the CDP roles which are mapped to specific course/resource
                        return $this->checkAccessToResource($cdpRoleIds, $resourceName, $ltiResourceInfoPK);
                    } else {
                        return false;
                    }
                 } else {
                     return true;
                 }
            }
        } else {
            return false;
        }
    }
    // BELOW function checks course mapped wit the roles
    // Implement the resource v/s roles check
    // CROSS VLIDATE THE GIVEN ROLES & RESOURCES from the table `lti_resource_access` 
    public function checkAccessToResource($cdpRoleIds = array(), $resourceName = NULL, $ltiResourceInfoPK = NULL) {
        if(count($cdpRoleIds) > 0) {
            $noAccess = 0;
            foreach($cdpRoleIds as $rK=>$rV) {
                $ltiResourceHandlerCondition =  " lti_resource_info_id = ". $ltiResourceInfoPK." AND tp_user_role_id = ".$rV. " AND lti_resource_handler_default = 1";
                $ltiResourceHandlerFields = array('lti_resource_handler_default');
                $ltiResourceHandlerRespArr = $this->tpDBObj->select(LTI_ACCESS_ROLES, $ltiResourceHandlerFields, $ltiResourceHandlerCondition);
                if(is_array($ltiResourceHandlerRespArr) && $ltiResourceHandlerRespArr['resultCount'] > 0 && $ltiResourceHandlerRespArr['status'] == 'success'){
                    //having access,
                } else {
                    $noAccess = $noAccess+1;
                }
            }
            if($noAccess > 0){
                return FALSE;
            } else {
                return TRUE;
            }
        } else {
            return FALSE;
        }
    }
    // NOT USING NOW
    public function checkResourceWithRole($roleName = NULL, $resourceId = NULL) {
        if($roleName && $resourceId ) {
            $roleName = strtolower($roleName);
            $roleRespArr = array();
            $roleCondition = " lti_user_role_name = '".$roleName."' OR lti_user_role_urn_name = '".$roleName."'";
            $roleFields = array('lti_user_role_id');
            $roleRespArr = $this->tpDBObj->select(LTI_USER_ROLE, $roleFields, $roleCondition);
            if(is_array($roleRespArr) && $roleRespArr['resultCount'] > 0 && $roleRespArr['status'] == 'success') {
                $roleID = $roleRespArr['result'][0]['lti_user_role_id'];
            }

            $checkAccessCondition = " lti_resource_info_id = ".$resourceId." AND lti_user_role_id = ".$roleID;//
            //." AND lti_resource_handler_default = ".LTI_ACTIVE;
            $checkFlds = array('lti_resource_handler_id');
            $accessPermission = $this->tpDBObj->select(LTI_RESOURCE_ACCESS, $checkFlds, $checkAccessCondition);
            if(is_array($accessPermission) && $accessPermission['resultCount'] > 0 && $accessPermission['result'][0]['lti_resource_handler_id'] > 0) 
            {
                return TRUE;
            } else {
                return FALSE;
            }
        } else {
            return FALSE;
        }
    }


    public function simplifyPostValues($params = array() ) {
        
        $params = (array)$params;
        if (is_array($params) && count($params) > 0 ) {
            foreach($params AS $arrKey=>$arrVal) {
                $k = trim($arrKey);
                $v = trim($arrVal);
                if(isset($v) && strlen($v) > 0) {
                    $returnArr[$k] = $v;
                } else {
                    unset($k);
                }
            }
            $returnArr = $this->tpDBObj->preventXssArray($returnArr);
            return $returnArr;
        } return array();
        
    }

    public function validateRegistrationValues($postParams = array(),$previousUrlPath =NULL){
     
        $message = ''; 
        $this->logErrorMessage("Tool registration required fields vaidation started. ");
        if(!isset($postParams['reg_key']) && strlen($postParams['reg_key']) < 1 ) 
            {   $message = 'reg_key value is missing';  }

        if(!isset($postParams['reg_password']) && strlen($postParams['reg_password']) < 1 ) 
            {   $message .= "reg_password value is missing";    }

        if(!isset($postParams['tc_profile_url']) && strlen($postParams['tc_profile_url']) < 1 ) 
            {   $message .= "tc_profile_url value is missing";  }
            
        if(!isset($postParams['lti_version']) && strlen($postParams['lti_version']) < 1)
            {   $message .= "lti_version value is missing"; }
            
        if(strtolower($postParams['lti_version']) != LTI_VERSION)
            {   $message .= "invalid lti_version value"; }

        if(!isset($postParams['launch_presentation_return_url']) && strlen($postParams['launch_presentation_return_url']) < 1 ) {
            //$message .= "launch_presentation_return_url value is missing";
            $launchPresentationReturnURL = $previousUrlPath;
        } else {
            $launchPresentationReturnURL = $postParams['launch_presentation_return_url'];
        }
        $this->logErrorMessage("Tool registration required fields vaidation completed. ");
        // IF one of the input param is missing redirect back to the TC defined url with valid message
        if(strlen($message) > 1 ) {
            return array('status'=>'failed','message'=>$message,'finalreturnURL'=>$launchPresentationReturnURL);
        } else {
            return array('status'=>'success','message'=>NULL,'finalreturnURL'=>$launchPresentationReturnURL);
        }
        
    }
    
    private function logErrorMessage ($message = NULL) {
        $logMessage = $message." - ".DATE('Y-m-d H:i:s')." \n";
         error_log($logMessage, 3, $this->logFilePath);
    }

    public function __destruct() {
        unset($this->tpDBObj);
        unset($this->oauthObj);
        unset($TpLaunchLtiObj);

        unset($this->logFilePath);
    }
    
    
} // END OF CLASS
