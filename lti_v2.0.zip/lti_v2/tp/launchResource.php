<?php
//launchResource.php

/**
 * Code in this page may have to be customized according to the application with which the library is being integrated.
 * 
 * Sample URL for launching the resource = http://mylocal/lti_v2/tp/launchResource.php?resourceId=B0011_VOL001 
 */

//echo "<pre>"; print_r($_POST); die;
ob_start();
require_once ('../tp/Tool_Provider_Class.php');

if(isset($_POST['launch_presentation_return_url'])) 
{ $returnURL = $_POST['launch_presentation_return_url']; } else { $returnURL = $_SERVER['HTTP_REFERER']; }

if (parse_url($returnURL, PHP_URL_QUERY))
{ $returnURL = $returnURL."&"; } else {	$returnURL = $returnURL."?"; }

if(isset($_GET['resourceId'])) {
	
    if(isset($_POST['lti_message_type']) && isset($_POST['lti_version']) && isset($_POST['resource_link_id'])) {
        $postParams = $_POST;
        $messageType = trim($postParams['lti_message_type']);

        if(strtolower($messageType) == 'basic-lti-launch-request'){
                // all the basic validation is success
                $tpObj = new Tool_Provider_Class();
                $resourceName = trim($_GET['resourceId']);
                $launchResp = $tpObj->toolLaunchRequest($postParams, $resourceName);

                if(isset($launchResp) && is_array($launchResp) && $launchResp['status'] == 'launch')
                {
                        $successMessage = $launchResp['message']; // usually it is "Success"
                        $resourceAccessLevel = $launchResp['resourceAccessLevel']; // usually 'd'/'s'/'m'
                        $callBackURL = $launchResp['callBackURL']; 

                        // create user info in to the tool providers db & create session accordingly with respect to access level 'd'/'s'/'m'

                        require_once "../library/tpdatabase.php";
                        $tpDBObj = new tpdatabase(); 
                        $cond = " lti_resource_info_uniq_id = '".$resourceName."'";
                        $info = $tpDBObj->select('lti_resource_info',array('lti_resource_info_uri_param_one'),$cond);
                        if(is_array($info) && $info['resultCount'] > 0){
                            $partId = $info['result'][0]['lti_resource_info_uri_param_one'];
                            if(isset($partId) && strlen($partId) > 0) {
                                $redirectPath_part = "http://local.panglobal/ltilaunch/".$partId."/".$resourceName;
                                header("Location: $redirectPath_part");
                            } else {
                                echo "No record found for the resource"; die;
                            }
                        } else {
                            echo "No record found for the resource"; die;
                        }
                } else {
                        $failuremsg = $launchResp['message'];
                        $returnPathURL = $returnURL.'status=failure&lti_errormsg='.urlencode($failuremsg);
                        header("Location: $returnPathURL");
                }

        } else {
            $message = "lti_message_type parameters is missing";
            $returnPath = $returnURL.'status=failure&lti_errormsg='.urlencode($message);
            header("Location: $returnPath");
        }

    } else {
        $error_msg = 'Mandatory fields are missing in the request';
        $returnPath = $returnURL.'lti_errormsg='.urlencode($error_msg);
        header("Location: $returnPath");
    }
} else {
	$err_msg = 'resource id is missing in the URL';
	$returnPath = $returnURL.'lti_errormsg='.urlencode($err_msg);
	header("Location: $returnPath");
}
		
unset($tpObj);
ob_end_flush();		

?>
